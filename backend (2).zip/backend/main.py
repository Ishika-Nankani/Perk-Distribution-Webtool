import os, csv, io, json
import numpy as np
from scipy.optimize import linear_sum_assignment
from flask import Flask, request, jsonify, send_from_directory

BASE_DIR     = os.path.dirname(__file__)
FRONTEND_DIR = os.path.abspath(os.path.join(BASE_DIR, '..', 'frontend'))

app = Flask(__name__,
            static_folder=FRONTEND_DIR,
            static_url_path='')  # serve static at /

@app.route('/')
def index():
    return send_from_directory(FRONTEND_DIR, 'index.html')


def parse_valuations_csv(file_stream):
    try:
        content = file_stream.read().decode('utf-8')
        reader = csv.reader(io.StringIO(content))
        rows = list(reader)
        
        if len(rows) < 2:
            raise ValueError("CSV file must contain at least 2 rows (header and data)")
        
        header = rows[0]
        if len(header) < 2:
            raise ValueError("CSV must contain at least one employee column")
            
        employees = header[1:]
        perks = []
        values = []
        
        for i, row in enumerate(rows[1:], 1):
            if len(row) != len(header):
                raise ValueError(f"Row {i} has incorrect number of columns")
            
            perks.append(row[0])
            vals = []
            for j, x in enumerate(row[1:], 1):
                try:
                    val = float(x)
                    if val < 0:
                        raise ValueError(f"Negative valuation at row {i}, column {j}")
                    vals.append(val)
                except ValueError:
                    raise ValueError(f"Invalid numeric value at row {i}, column {j}: {x}")
            values.append(vals)
            
        V = np.array(values).T  # shape (n_employees × m_perks)
        return employees, perks, V
        
    except UnicodeDecodeError:
        raise ValueError("Invalid file encoding. Please ensure the CSV file is UTF-8 encoded")
    except csv.Error:
        raise ValueError("Invalid CSV format")


def compute_payments_from_bundles(V, bundles):
    n, m = V.shape
    # build envy graph weights
    w = np.zeros((n,n))
    for i in range(n):
        vi_i = V[i, bundles[i]].sum()
        for k in range(n):
            vi_k = V[i, bundles[k]].sum()
            w[i,k] = vi_k - vi_i

    # Bellman-Ford to get ℓ(i)
    def compute_l(src):
        dist = [float('inf')]*n
        dist[src] = 0.0
        for _ in range(n-1):
            updated = False
            for u in range(n):
                if dist[u]==float('inf'): continue
                for v in range(n):
                    nd = dist[u] + (-w[u][v])
                    if nd < dist[v]:
                        dist[v] = nd
                        updated = True
            if not updated: break
        best = 0.0
        for d in dist:
            if d< float('inf'):
                best = max(best, -d)
        return best

    ls = [compute_l(i) for i in range(n)]
    min_l = min(ls)
    payments = [l-min_l for l in ls]
    return payments


@app.route('/compute', methods=['POST'])
def compute():
    # 1) parse valuations CSV
    if 'csvfile' not in request.files:
        return jsonify({'error':'Missing csvfile'}),400
    emps, prks, V = parse_valuations_csv(request.files['csvfile'])
    n, m = V.shape

    # 2) EF1 allocation by round‑robin max‑weight matching
    unassigned = list(range(m))
    bundles    = [[] for _ in range(n)]
    while unassigned:
        k = len(unassigned)
        cols = unassigned + [None]*(max(0,n-k))
        cost = np.zeros((n, len(cols)))
        for i in range(n):
            for jpos, j in enumerate(cols):
                cost[i,jpos] = -V[i,j] if j is not None else 0.0
        row_ind, col_ind = linear_sum_assignment(cost)
        assigned = set()
        for i,c in zip(row_ind, col_ind):
            if c<k:
                j = unassigned[c]
                bundles[i].append(j)
                assigned.add(j)
        unassigned = [j for j in unassigned if j not in assigned]

    # 3) payments
    payments  = compute_payments_from_bundles(V, bundles)

    # 4) format assignment
    assignment = [[prks[j] for j in bundles[i]] for i in range(n)]
    return jsonify({
        'employees':  emps,
        'assignment': assignment,
        'payments':   payments
    })


@app.route('/payments', methods=['POST'])
def payments_only():
    # parse CSV
    if 'csvfile' not in request.files:
        return jsonify({'error':'Missing csvfile'}),400
    emps, prks, V = parse_valuations_csv(request.files['csvfile'])
    n,m = V.shape

    # parse assignment JSON
    if 'assignment' not in request.form:
        return jsonify({'error':'Missing assignment JSON'}),400
    try:
        assignment = json.loads(request.form['assignment'])
        # assignment should be list-of-lists with same length as emps
        if len(assignment)!=len(emps):
            raise ValueError
    except:
        return jsonify({'error':'Invalid assignment format'}),400

    # build bundles as indices
    perk_index = {p:i for i,p in enumerate(prks)}
    bundles = []
    for emp_bundle in assignment:
        idxs = []
        for p in emp_bundle:
            if p in perk_index:
                idxs.append(perk_index[p])
        bundles.append(idxs)

    payments = compute_payments_from_bundles(V, bundles)
    return jsonify({
        'employees': emps,
        'payments':  payments
    })


if __name__=='__main__':
    app.run(debug=True)
