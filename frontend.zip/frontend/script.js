// Common state and helpers
let lastResult = null;
const resultDiv = document.getElementById('result');

function showError(message, container = resultDiv) {
  const errorDiv = document.createElement('div');
  errorDiv.className = 'error-message';
  errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
  container.innerHTML = '';
  container.appendChild(errorDiv);
}

function validateInputs(form) {
  const inputs = form.querySelectorAll('input[required], textarea[required]');
  let isValid = true;
  let firstInvalid = null;

  inputs.forEach(input => {
    const isValueValid = input.type === 'number' ? 
      !isNaN(input.value) && parseFloat(input.value) >= 0 : 
      input.value.trim() !== '';
      
    if (!isValueValid) {
      input.classList.add('invalid');
      isValid = false;
      if (!firstInvalid) firstInvalid = input;
    } else {
      input.classList.remove('invalid');
    }
  });

  if (firstInvalid) {
    firstInvalid.focus();
    showError('Please fill in all required fields correctly', firstInvalid.closest('form').querySelector('.error-container') || resultDiv);
  }

  return isValid;
}

function showLoader(btn) {
  btn.disabled = true;
  btn.innerHTML = '<span class="loader"></span>Working…';
}

function hideLoader(btn, text, icon = 'fa-cog') {
  btn.disabled = false;
  btn.innerHTML = `<i class="fas ${icon}"></i>${text}`;
}

function resetForms() {
  const forms = ['computeForm', 'manualInputForm', 'paymentsForm'];
  forms.forEach(formId => {
    const form = document.getElementById(formId);
    if (form) form.reset();
  });

  const containers = ['perksContainer', 'agentsContainer', 'valuationContainer'];
  containers.forEach(id => {
    const container = document.getElementById(id);
    if (container) container.style.display = 'none';
  });

  if (resultDiv) {
    resultDiv.innerHTML = '';
    document.getElementById('resultActions').style.display = 'none';
  }
}

function getPerkIcon(perkName) {
  const icons = {
    'parking': 'fa-car',
    'gym': 'fa-dumbbell',
    'cafeteria': 'fa-utensils',
    'insurance': 'fa-shield-heart',
    'remote': 'fa-laptop-house',
    'education': 'fa-graduation-cap',
    'childcare': 'fa-baby',
    'transport': 'fa-bus',
    'health': 'fa-heart-pulse',
    'dental': 'fa-tooth',
    'vision': 'fa-eye',
    'stocks': 'fa-chart-line',
    'bonus': 'fa-sack-dollar',
    'vacation': 'fa-umbrella-beach'
  };
  
  // Try to match perk name with icon
  const key = Object.keys(icons).find(k => 
    perkName.toLowerCase().includes(k.toLowerCase())
  );
  return icons[key] || 'fa-gift';
}

function renderTable(employees, assignment, payments) {
  lastResult = { employees, assignment, payments };
  const card = document.createElement('div');
  card.className = 'result-card';
  
  // Enhanced summary header with HR theme
  const totalPayment = payments.reduce((sum, p) => sum + p, 0);
  const summary = document.createElement('div');
  summary.className = 'result-summary';
  summary.innerHTML = `
    <div class="summary-header">
      <i class="fas fa-clipboard-list-check"></i>
      <div>
        <h3>Distribution Report</h3>
        <p class="summary-subtitle">Fair allocation achieved with minimal subsidies</p>
      </div>
    </div>
    <div class="summary-stats">
      <div class="stat">
        <i class="fas fa-users"></i>
        <span class="stat-label">Team Members</span>
        <span class="stat-value">${employees.length}</span>
      </div>
      <div class="stat">
        <i class="fas fa-coins"></i>
        <span class="stat-label">Total Subsidy</span>
        <span class="stat-value">$${totalPayment.toFixed(2)}</span>
      </div>
      <div class="stat">
        <i class="fas fa-calculator"></i>
        <span class="stat-label">Avg. Payment</span>
        <span class="stat-value">$${(totalPayment / employees.length).toFixed(2)}</span>
      </div>
      ${assignment ? `
      <div class="stat">
        <i class="fas fa-gift"></i>
        <span class="stat-label">Total Perks</span>
        <span class="stat-value">${assignment.reduce((sum, perks) => sum + perks.length, 0)}</span>
      </div>
      ` : ''}
    </div>
  `;
  card.appendChild(summary);
  
  // Enhanced table with perk icons and better formatting
  let html = '<div class="table-wrapper"><table><thead><tr>' +
    '<th><i class="fas fa-user-tie"></i> Employee</th>' +
    '<th><i class="fas fa-gift"></i> Allocated Perks</th>' +
    '<th><i class="fas fa-coins"></i> Subsidy</th>' +
    '</tr></thead><tbody>';
    
  for (let i = 0; i < employees.length; i++) {
    const perks = assignment ? assignment[i].map(perk => 
      `<span class="perk-badge">
        <i class="fas ${getPerkIcon(perk)}"></i>
        ${perk}
       </span>`
    ).join('') : '—';
    
    html += `
      <tr style="animation: fadeIn 0.3s ${i * 0.1}s forwards;">
        <td>
          <div class="employee-cell">
            <i class="fas fa-user-circle"></i>
            <span>${employees[i]}</span>
          </div>
        </td>
        <td>
          <div class="perks-cell">
            ${perks}
          </div>
        </td>
        <td>
          <div class="payment-cell ${payments[i] === 0 ? 'no-payment' : ''}">
            $${payments[i].toFixed(2)}
          </div>
        </td>
      </tr>
    `;
  }
  html += '</tbody></table></div>';
  
  const tableContainer = document.createElement('div');
  tableContainer.className = 'table-container';
  tableContainer.innerHTML = html;
  card.appendChild(tableContainer);
  
  document.getElementById('resultActions').style.display = 'flex';
  return card;
}

// File upload handling
document.querySelectorAll('input[type="file"]').forEach(input => {
  input.addEventListener('change', e => {
    const fileName = e.target.files[0]?.name || '';
    const fileNameSpan = e.target.parentElement.querySelector('.file-name');
    if (fileNameSpan) {
      fileNameSpan.textContent = fileName ? `Selected: ${fileName}` : '';
    }
  });
});

// Mode 1 page functionality
if (window.location.pathname.includes('mode1.html')) {
  // Input method switching
  document.querySelectorAll('.method-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.method-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      const method = btn.dataset.method;
      document.querySelector('.csv-section').style.display = method === 'csv' ? 'block' : 'none';
      document.querySelector('.manual-section').style.display = method === 'manual' ? 'block' : 'none';
    });
  });

  // Manual input handling
  const manualForm = document.getElementById('manualInputForm');
  const perkInputs = document.getElementById('perkInputs');
  const agentInputs = document.getElementById('agentInputs');
  const valuationMatrix = document.getElementById('valuationMatrix');
  let perks = [];
  let agents = [];

  document.getElementById('setPerkCount')?.addEventListener('click', () => {
    const count = parseInt(document.getElementById('numPerks').value);
    if (count > 0) {
      perkInputs.innerHTML = '';
      for (let i = 0; i < count; i++) {
        const input = document.createElement('input');
        input.type = 'text';
        input.placeholder = `Perk ${i + 1} name`;
        input.required = true;
        perkInputs.appendChild(input);
      }
      document.getElementById('perksContainer').style.display = 'block';
    }
  });

  document.getElementById('confirmPerks')?.addEventListener('click', () => {
    perks = Array.from(perkInputs.querySelectorAll('input')).map(input => input.value.trim());
    if (perks.every(perk => perk)) {
      document.getElementById('agentsContainer').style.display = 'block';
    } else {
      alert('Please fill in all perk names');
    }
  });

  document.getElementById('setAgentCount')?.addEventListener('click', () => {
    const count = parseInt(document.getElementById('numAgents').value);
    if (count > 0) {
      agentInputs.innerHTML = '';
      for (let i = 0; i < count; i++) {
        const input = document.createElement('input');
        input.type = 'text';
        input.placeholder = `Agent ${i + 1} name`;
        input.required = true;
        agentInputs.appendChild(input);
      }
      createValuationMatrix();
      document.getElementById('valuationContainer').style.display = 'block';
    }
  });

  function createValuationMatrix() {
    valuationMatrix.innerHTML = '';
    agents = Array.from(agentInputs.querySelectorAll('input')).map(input => input.value.trim() || input.placeholder);
    
    const headerRow = document.createElement('div');
    headerRow.className = 'valuation-row';
    headerRow.innerHTML = '<label></label>' + perks.map(perk => 
      `<label style="text-align: center">${perk}</label>`
    ).join('');
    valuationMatrix.appendChild(headerRow);
    
    agents.forEach((agent, i) => {
      const row = document.createElement('div');
      row.className = 'valuation-row';
      row.innerHTML = `<label>${agent}:</label>` + 
        perks.map((_, j) => 
          `<input type="number" step="0.1" required data-i="${i}" data-j="${j}">`
        ).join('');
      valuationMatrix.appendChild(row);
    });
  }

  // Form submissions
  manualForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!validateInputs(manualForm)) return;
    
    resultDiv.innerHTML = '';
    const btn = document.getElementById('computeManual');
    showLoader(btn);

    try {
      const inputs = Array.from(valuationMatrix.querySelectorAll('input'));
      const values = [];
      perks.forEach((_, j) => {
        const row = [perks[j]];
        agents.forEach((_, i) => {
          const input = inputs.find(inp => 
            inp.dataset.i === i.toString() && 
            inp.dataset.j === j.toString()
          );
          row.push(input.value);
        });
        values.push(row.join(','));
      });
      
      const actualAgents = Array.from(agentInputs.querySelectorAll('input'))
        .map(input => input.value.trim() || input.placeholder);
      
      const csvContent = [',' + actualAgents.join(','), ...values].join('\n');
      const csvFile = new File([csvContent], 'manual-input.csv', { type: 'text/csv' });
      
      const fd = new FormData();
      fd.append('csvfile', csvFile);

      const res = await fetch('/compute', { method: 'POST', body: fd });
      const data = await res.json();
      
      if (!res.ok) throw new Error(data.error || res.statusText);
      data.employees = actualAgents;
      const card = renderTable(data.employees, data.assignment, data.payments);
      resultDiv.appendChild(card);
    } catch (err) {
      showError(err.message);
    } finally {
      hideLoader(btn, 'Compute Allocation', 'fa-cog');
    }
  });

  document.getElementById('computeForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    if (!validateInputs(e.target)) return;
    
    resultDiv.innerHTML = '';
    const file = document.getElementById('csvCompute').files[0];
    const btn = document.getElementById('btnCompute');
    showLoader(btn);

    const fd = new FormData();
    fd.append('csvfile', file);

    try {
      const res = await fetch('/compute', {method: 'POST', body: fd});
      const data = await res.json();
      
      if (!res.ok) throw new Error(data.error || res.statusText);
      const card = renderTable(data.employees, data.assignment, data.payments);
      resultDiv.appendChild(card);
    } catch (err) {
      showError(err.message);
    } finally {
      hideLoader(btn, 'Compute Allocation', 'fa-cog');
    }
  });
}

// Mode 2 page functionality
if (window.location.pathname.includes('mode2.html')) {
  document.getElementById('paymentsForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    if (!validateInputs(e.target)) return;
    
    resultDiv.innerHTML = '';
    const file = document.getElementById('csvPay').files[0];
    const assignJSON = document.getElementById('assignJSON').value.trim();
    const btn = document.getElementById('btnPay');
    showLoader(btn);

    // Validate JSON format
    try {
      JSON.parse(assignJSON);
    } catch (e) {
      showError('Invalid JSON format in assignment field');
      hideLoader(btn, 'Compute Payments', 'fa-cog');
      return;
    }

    const fd = new FormData();
    fd.append('csvfile', file);
    fd.append('assignment', assignJSON);

    try {
      const res = await fetch('/payments', {method: 'POST', body: fd});
      const data = await res.json();
      
      if (!res.ok) throw new Error(data.error || res.statusText);
      const card = renderTable(data.employees, null, data.payments);
      resultDiv.appendChild(card);
    } catch (err) {
      showError(err.message);
    } finally {
      hideLoader(btn, 'Compute Payments', 'fa-cog');
    }
  });
}

// Result actions
document.getElementById('downloadResult')?.addEventListener('click', () => {
  if (!lastResult) return;
  
  const { employees, assignment, payments } = lastResult;
  const content = [
    ['Employee', 'Assigned Perks', 'Payment'],
    ...employees.map((emp, i) => [
      emp,
      assignment ? assignment[i].join('; ') : '—',
      payments[i].toFixed(2)
    ])
  ].map(row => row.join(',')).join('\n');

  const blob = new Blob([content], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'allocation-result.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
});

document.getElementById('backToHome')?.addEventListener('click', () => {
  resetForms();
});
